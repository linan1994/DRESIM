from django.apps import AppConfig


class MapdemoConfig(AppConfig):
    name = 'mapdemo'
