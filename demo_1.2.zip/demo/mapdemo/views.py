from django.shortcuts import render
# from mapdemo.models import Node
import json
import numpy as np
import random
import time
from cvxopt import matrix, solvers


cal_need = True
n = 4 # number of points
t = n+1 # number of actions for each point
matrix_T = None # transition matrix
matrix_R = None # reward matrix
matrix_V = None # value matrix
matrix_P = None # policy matrix
longitude = [285.894, 285.954, 285.924, 286.014]
latitude = [40.7108, 40.7028, 40.6528, 40.7148]
state = ['0', '0', '0', '0']
new_state = ['0', '0', '0', '0']


def createRewardMatrix(n, t):
    matrix_R = np.array([[random.uniform(2, 15) for _ in range(t)] for _ in range(2**n)])
    # if this state does nothing, its reward should be the lowest
    for i in range(2**n):
        matrix_R[i][t-1] = 2.0
    return matrix_R


def createTransitionMatrix(n, t):
    """
    A example to explain my transition matrix: now state is 0111(1 represents broken, 0 represents not broken),
    do action 3(repair point 3), next states could be: 0110, 1110(simulate failure of a good point, and maintenance would always be successful).
    """
    matrix = [[[0 for _ in range(2**n)] for _ in range(t)] for _ in range(2**n)]

    for i in range(2**n):
        for j in range(t-1):
            all_pos = [] # all possible next states
            now_points = bin(i)[2:]
            now_points = "".join(["0" for _ in range(n - len(now_points))]) + now_points
            now_points = list(now_points)
            if t == n + 1:
                if j < t-1:
                    now_points[j] = '0'
            else:
                action = bin(j)[2:]
                action = "".join(["0" for _ in range(n - len(action))]) + action
                for p, a in enumerate(action):
                    if a == '1':
                        now_points[p] = '0'
            all_pos.append(int("".join(now_points), 2))
            for z in range(len(now_points)):
                tmp = now_points[:]
                if now_points[z] == '0' and z != j:
                    tmp[z] = '1'
                    all_pos.append(int("".join(tmp), 2))

            for pos in all_pos:
                if pos == int("".join(now_points), 2):
                    matrix[i][j][pos] = 0.3
                else:
                    matrix[i][j][pos] = 0.7/(len(all_pos)-1) + np.random.random()*0.5
        for z in range(2**n):
            matrix[i][t-1][z] = np.random.random()
    return np.array(matrix)


def solve(matrix_T, matrix_R, n, t):
    """
    Compute to get value matrix
    """
    solvers.options['show_progress'] = False
    P = np.zeros((2**n, 2**n))
    P = matrix(P)
    q = np.ones((2**n, 1))
    q = matrix(q)

    h = matrix_R.reshape(matrix_R.shape[0]*matrix_R.shape[1], 1)
    h = matrix(h)

    G = np.zeros(((2**n)*(t), 2**n))

    for i in range((2**n)*(t)):
        for j in range(t):
            G[i][i//(t)] = sum(matrix_T[i//(t)][j]) - 1

    G = matrix(G)
    sol = solvers.qp(P, q, G, h)
    values = np.array(sol['x'])

    return values


def createPolicyMatrix(matrix_T, matrix_R, matrix_V, n, t):
    """
    Based on value matrix, compute policy matrix.
    """
    matrix_P = [-1 for _ in range(2 ** n)]
    for i in range((2**n)):
        max = float('-inf')
        action = -1
        for j in range(t):
            res = matrix_R[i][j] + sum(matrix_T[i][j])*matrix_V[i]
            if res > max:
                max = res
                action = j
        matrix_P[i] = action

    return np.array(matrix_P)


def simulate(points, matrix_T, matrix_P):
    state = int(points, 2)
    action = matrix_P[state]

    probability = matrix_T[state][action]

    max_prob = float('-inf')
    next_state = 0
    for i, prob in enumerate(probability):
        if prob > max_prob:
            max_prob = prob
            next_state = i

    return bin(next_state)[2:], action, probability


# Create your views here.
def send_info(request):

    global cal_need, n, t, matrix_T, matrix_V, matrix_R, matrix_P, state, longitude, latitude, new_state
    long = 285.994
    lat = 40.7128
    if request.method == 'POST':
        if '3' in request.POST: # change number of actions
            if t == n+1:
                t = 2**n
                cal_need = True
            else:
                t = n+1
                cal_need = True

        elif '2' in request.POST: # read own csv file
            csv_file = request.FILES["csv_file"]
            file_data = csv_file.read().decode("utf-8")

            lines = file_data.split("\n")
            for line in lines:
                line = line.replace(',', '')
                line = list(line)
                line = list(map(int, line))
                matrix_P = np.array(line)

        elif '4' in request.POST: # change number of points
            n = request.POST.get('5')
            n = int(n)
            t = n+1
            state = ['0' for _ in range(n)]
            new_state = state[:]
            longitude = [long + 0.2*np.random.random()-0.1 for _ in range(n)]
            latitude = [lat + 0.2*np.random.random()-0.1 for _ in range(n)]
            cal_need = True


    state = new_state[:]
    # print(t)
    print(state)
    if cal_need is True:
        # if change number of points or actions, re-calculate matrix needed.
        print("do some thing!")
        matrix_T = createTransitionMatrix(n, t)
        matrix_R = createRewardMatrix(n, t)

        matrix_V = solve(matrix_T, matrix_R, n, t)
        matrix_P = createPolicyMatrix(matrix_T, matrix_R, matrix_V, n, t)

        cal_need = False
    print("matrix_P {}".format(matrix_P))
    print("matrix_P's shape {}".format(matrix_P.shape))
    # print("matrix_T' {}".format(matrix_T[1]))
    print("matrix_R's shape {}".format(matrix_R.shape))
    print("matrix_V's shape {}".format(matrix_V.shape))

    points, action, probability = simulate("".join(state), matrix_T, matrix_P)
    points = "".join(["0" for _ in range(n-len(points))]) + points

    actions = ["NO" for _ in range(n)]
    if t == n+1:
        if action != n:
            actions[action] = "YES"
    elif t == 2**n:
        action = bin(action)[2:]
        action = "".join(["0" for _ in range(n - len(action))]) + action
        for i, a in enumerate(action):
            if a == '1':
                actions[i] = 'YES'

    repaired = []
    for i, a in enumerate(actions):
        if a == 'YES':
            repaired.append(i)

    # warning_scores = []
    warning_scores = [0 for _ in range(n)]
    # warning_score = 0.0
    # print(probability)
    for i, prob in enumerate(probability):
        tmp = bin(i)[2:]
        # print("tmp: {}".format(tmp))
        for j, s in enumerate(tmp):
            # print("s: {}".format(s))
            if s == '1' and warning_scores[j] + prob < 1.0:
                warning_scores[j] += prob
    new_state = list(points)
    print(state)

    return render(request, "demo.html", {'longitude': json.dumps(longitude),
                                         'latitude': json.dumps(latitude),
                                         'state': json.dumps(state),
                                         'actions': actions,
                                         'warning_scores': warning_scores,
                                         'repaired': json.dumps(repaired)})

